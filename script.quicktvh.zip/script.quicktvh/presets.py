SERVER_ADDON = "service.tvheadend42"
CLIENT_ADDON = "pvr.hts"
SECONDS_PER_MUX = 30
LCN_RETRIES = 3