#SERVER_ADDON = "service.tvheadend99"
SERVER_ADDON = "service.tvheadend43"
CLIENT_ADDON = "pvr.hts"
SECONDS_PER_MUX = 30
LCN_RETRIES = 3